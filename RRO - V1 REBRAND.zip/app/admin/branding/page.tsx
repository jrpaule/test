"use client"

import { useState } from "react"
import { brandConfig } from "@/lib/brand-config"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Logo } from "@/components/brand/logo"
import { AlertTriangle, Save, Upload } from "lucide-react"

export default function BrandingConfigPage() {
  const [brandSettings, setBrandSettings] = useState({
    ...brandConfig,
  })

  const [previewMode, setPreviewMode] = useState<"light" | "dark">("light")
  const [isSaving, setIsSaving] = useState(false)

  const handleCompanyChange = (field: string, value: string) => {
    setBrandSettings({
      ...brandSettings,
      company: {
        ...brandSettings.company,
        [field]: value,
      },
    })
  }

  const handleColorChange = (colorName: string, value: string) => {
    setBrandSettings({
      ...brandSettings,
      colors: {
        ...brandSettings.colors,
        [colorName]: value,
      },
    })
  }

  const handleSave = async () => {
    setIsSaving(true)

    // In a real implementation, this would save to a database or API
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Show success message
    alert("Brand settings saved successfully!")
    setIsSaving(false)
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold font-heading text-primary">Brand Configuration</h1>
          <p className="text-muted-foreground">Customize your Rapid Restore Ontario branding</p>
        </div>
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ? (
            <>
              <span className="animate-spin mr-2">⟳</span> Saving...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" /> Save Changes
            </>
          )}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Tabs defaultValue="company">
            <TabsList className="grid grid-cols-4 mb-6">
              <TabsTrigger value="company">Company</TabsTrigger>
              <TabsTrigger value="colors">Colors</TabsTrigger>
              <TabsTrigger value="typography">Typography</TabsTrigger>
              <TabsTrigger value="assets">Assets</TabsTrigger>
            </TabsList>

            <TabsContent value="company" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Company Information</CardTitle>
                  <CardDescription>Update your company details and contact information</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="company-name">Company Name</Label>
                      <Input
                        id="company-name"
                        value={brandSettings.company.name}
                        onChange={(e) => handleCompanyChange("name", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="company-shortName">Short Name</Label>
                      <Input
                        id="company-shortName"
                        value={brandSettings.company.shortName}
                        onChange={(e) => handleCompanyChange("shortName", e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="company-tagline">Tagline</Label>
                    <Input
                      id="company-tagline"
                      value={brandSettings.company.tagline}
                      onChange={(e) => handleCompanyChange("tagline", e.target.value)}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="company-phone">Phone Number</Label>
                      <Input
                        id="company-phone"
                        value={brandSettings.company.phone}
                        onChange={(e) => handleCompanyChange("phone", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="company-email">Email Address</Label>
                      <Input
                        id="company-email"
                        value={brandSettings.company.email}
                        onChange={(e) => handleCompanyChange("email", e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="company-address">Address</Label>
                    <Textarea
                      id="company-address"
                      value={brandSettings.company.address}
                      onChange={(e) => handleCompanyChange("address", e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="colors" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Brand Colors</CardTitle>
                  <CardDescription>Customize your brand color palette</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>Primary Color</Label>
                      <div className="flex items-center gap-2">
                        <div
                          className="w-10 h-10 rounded-md border"
                          style={{ backgroundColor: brandSettings.colors.primary }}
                        />
                        <Input
                          value={brandSettings.colors.primary}
                          onChange={(e) => handleColorChange("primary", e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Secondary Color</Label>
                      <div className="flex items-center gap-2">
                        <div
                          className="w-10 h-10 rounded-md border"
                          style={{ backgroundColor: brandSettings.colors.secondary }}
                        />
                        <Input
                          value={brandSettings.colors.secondary}
                          onChange={(e) => handleColorChange("secondary", e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Accent Color</Label>
                      <div className="flex items-center gap-2">
                        <div
                          className="w-10 h-10 rounded-md border"
                          style={{ backgroundColor: brandSettings.colors.accent }}
                        />
                        <Input
                          value={brandSettings.colors.accent}
                          onChange={(e) => handleColorChange("accent", e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Dark Color</Label>
                      <div className="flex items-center gap-2">
                        <div
                          className="w-10 h-10 rounded-md border"
                          style={{ backgroundColor: brandSettings.colors.dark }}
                        />
                        <Input
                          value={brandSettings.colors.dark}
                          onChange={(e) => handleColorChange("dark", e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Light Color</Label>
                      <div className="flex items-center gap-2">
                        <div
                          className="w-10 h-10 rounded-md border"
                          style={{ backgroundColor: brandSettings.colors.light }}
                        />
                        <Input
                          value={brandSettings.colors.light}
                          onChange={(e) => handleColorChange("light", e.target.value)}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <div className="flex items-start gap-2 text-sm text-muted-foreground">
                    <AlertTriangle className="h-4 w-4 mt-0.5" />
                    <p>
                      Changing colors requires rebuilding the Tailwind CSS theme. Contact your developer for full
                      implementation.
                    </p>
                  </div>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="typography" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Typography</CardTitle>
                  <CardDescription>Configure your brand typography</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="heading-font">Heading Font</Label>
                      <Input
                        id="heading-font"
                        value={brandSettings.typography.headingFont}
                        onChange={(e) =>
                          setBrandSettings({
                            ...brandSettings,
                            typography: {
                              ...brandSettings.typography,
                              headingFont: e.target.value,
                            },
                          })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="body-font">Body Font</Label>
                      <Input
                        id="body-font"
                        value={brandSettings.typography.bodyFont}
                        onChange={(e) =>
                          setBrandSettings({
                            ...brandSettings,
                            typography: {
                              ...brandSettings.typography,
                              bodyFont: e.target.value,
                            },
                          })
                        }
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Font Preview</Label>
                    <div className="p-4 border rounded-md">
                      <h2
                        style={{ fontFamily: brandSettings.typography.headingFont }}
                        className="text-2xl font-bold mb-2"
                      >
                        Heading Font
                      </h2>
                      <p style={{ fontFamily: brandSettings.typography.bodyFont }} className="text-base">
                        This is body text in the selected font. The quick brown fox jumps over the lazy dog.
                      </p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <div className="flex items-start gap-2 text-sm text-muted-foreground">
                    <AlertTriangle className="h-4 w-4 mt-0.5" />
                    <p>
                      Font changes require updating the font imports in the layout file. Contact your developer for full
                      implementation.
                    </p>
                  </div>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="assets" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Brand Assets</CardTitle>
                  <CardDescription>Upload and manage your brand assets</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Primary Logo</Label>
                    <div className="border rounded-md p-4 flex flex-col items-center justify-center">
                      <div className="bg-gray-50 p-6 rounded-md mb-4">
                        <Logo size="lg" />
                      </div>
                      <Button variant="outline" size="sm">
                        <Upload className="h-4 w-4 mr-2" />
                        Upload New Logo
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>White Logo (for dark backgrounds)</Label>
                    <div className="border rounded-md p-4 flex flex-col items-center justify-center bg-primary">
                      <div className="p-6 rounded-md mb-4">
                        <Logo variant="white" size="lg" />
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="bg-white/20 text-white border-white/40 hover:bg-white/30"
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Upload New Logo
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Favicon</Label>
                    <div className="border rounded-md p-4 flex flex-col items-center justify-center">
                      <div className="bg-gray-50 p-6 rounded-md mb-4">
                        <img src="/favicon.ico" alt="Favicon" className="w-16 h-16" />
                      </div>
                      <Button variant="outline" size="sm">
                        <Upload className="h-4 w-4 mr-2" />
                        Upload New Favicon
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Brand Preview</CardTitle>
              <CardDescription>See how your brand looks</CardDescription>
              <div className="flex gap-2 mt-2">
                <Button
                  variant={previewMode === "light" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setPreviewMode("light")}
                >
                  Light
                </Button>
                <Button
                  variant={previewMode === "dark" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setPreviewMode("dark")}
                >
                  Dark
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div
                className={`border rounded-md overflow-hidden ${previewMode === "dark" ? "bg-gray-900 text-white" : "bg-white"}`}
              >
                <div
                  className="p-4 border-b"
                  style={{
                    backgroundColor: previewMode === "dark" ? brandSettings.colors.dark : brandSettings.colors.primary,
                    color: "white",
                  }}
                >
                  <Logo variant={previewMode === "dark" ? "white" : "white"} withTagline />
                </div>

                <div className="p-4 space-y-4">
                  <h3 style={{ fontFamily: brandSettings.typography.headingFont }} className="text-xl font-bold">
                    Welcome to {brandSettings.company.name}
                  </h3>

                  <p style={{ fontFamily: brandSettings.typography.bodyFont }}>
                    We provide 24/7 emergency restoration services across Ontario.
                  </p>

                  <div className="flex gap-2">
                    <Button
                      style={{
                        backgroundColor: brandSettings.colors.secondary,
                        color: "white",
                      }}
                    >
                      Emergency Call
                    </Button>

                    <Button
                      variant="outline"
                      style={{
                        borderColor: previewMode === "dark" ? "white" : brandSettings.colors.primary,
                        color: previewMode === "dark" ? "white" : brandSettings.colors.primary,
                      }}
                    >
                      Learn More
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
