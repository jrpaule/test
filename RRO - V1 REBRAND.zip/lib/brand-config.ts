// Brand configuration for Rapid Restore Ontario
export const brandConfig = {
  // Company information
  company: {
    name: "Rapid Restore Ontario",
    shortName: "Rapid Restore",
    tagline: "Ontario's 24/7 Emergency Restoration Experts",
    phone: "1-800-555-HELP",
    email: "help@rapidrestoreontario.com",
    address: "123 Restoration Ave, Toronto, ON M5V 2K7",
    founded: "2010",
  },

  // Brand colors
  colors: {
    primary: "#2A5C82", // Ontario-themed blue
    secondary: "#E57200", // Alert orange
    accent: "#00843D", // Ontario green
    dark: "#1A365D",
    light: "#F5F7FA",
    success: "#2E7D32",
    warning: "#F57C00",
    error: "#D32F2F",
    info: "#0288D1",
  },

  // Typography
  typography: {
    headingFont: "'Roboto Condensed', sans-serif",
    bodyFont: "'Open Sans', sans-serif",
    baseSize: "16px",
    scale: 1.2,
  },

  // Social media
  social: {
    facebook: "https://facebook.com/rapidrestoreontario",
    twitter: "https://twitter.com/rapidrestoreON",
    instagram: "https://instagram.com/rapidrestoreontario",
    linkedin: "https://linkedin.com/company/rapid-restore-ontario",
  },

  // Service locations in Ontario
  locations: [
    {
      id: "toronto",
      city: "Toronto",
      province: "ON",
      serviceArea: ["Etobicoke", "North York", "Scarborough", "Downtown"],
      phoneNumber: "416-555-1234",
    },
    {
      id: "ottawa",
      city: "Ottawa",
      province: "ON",
      serviceArea: ["Centretown", "Kanata", "Orleans", "Nepean"],
      phoneNumber: "613-555-5678",
    },
    {
      id: "hamilton",
      city: "Hamilton",
      province: "ON",
      serviceArea: ["Stoney Creek", "Dundas", "Ancaster", "Burlington"],
      phoneNumber: "905-555-9012",
    },
    {
      id: "london",
      city: "London",
      province: "ON",
      serviceArea: ["Downtown", "Byron", "Masonville", "Lambeth"],
      phoneNumber: "519-555-3456",
    },
  ],

  // Emergency service types
  services: {
    water: {
      title: "Water Damage",
      responseTime: "45 minutes",
    },
    fire: {
      title: "Fire Damage",
      responseTime: "60 minutes",
    },
    mold: {
      title: "Mold Remediation",
      responseTime: "24 hours",
    },
    storm: {
      title: "Storm Damage",
      responseTime: "90 minutes",
    },
  },
}
